import java.awt.*;
import java.awt.event.*;
import javax.accessibility.Accessible;
import javax.swing.*;
//Making a separate class for registration page and submission
class frame2 extends Frame  {

    public void frame2() {
        //Frame f1 = new Frame("frame2");
        TextField tf1, tf2, tf3, tf4 = new TextField(), tf5 = new TextField();
        Button b1, b2;
        Label l1 = new Label("Username");
        Label l2 = new Label("Password");
        Label l3 = new Label("phone");
        Label l4 = new Label("City");
        Label l5 = new Label("Atm Pin");
        l1.setBounds(50, 70, 60, 20);
        tf1 = new TextField();
        tf1.setBounds(50, 50, 150, 20);
        tf2 = new TextField();
        tf2.setBounds(220, 50, 150, 20);
        l2.setBounds(220, 70, 60, 20);
        tf3 = new TextField();
        tf3.setBounds(50, 100, 150, 20);
        l3.setBounds(50, 120, 150, 20);
        tf4.setBounds(220, 100, 150, 20);
        l4.setBounds(220, 120, 150, 20);
        tf5.setBounds(50, 140, 150, 20);
        l5.setBounds(50, 160, 60, 20);

        b1 = new Button("Register");
        b1.setBounds(200, 200, 70, 20);
        b2 = new Button();
        b2.setBounds(120, 200, 50, 20);
        // adding action listener to register button
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s1 = tf1.getText();
                String s2 = tf2.getText();
                String s3 = tf3.getText();
//                Frame j = new Frame();
//                popup p = new popup();
                final JFrame j = new JFrame();
                JButton jb = new JButton();
                jb.setText("Thankyou You have been registered ");
                jb.setBackground(Color.blue);
                jb.setForeground(Color.red);
                j.setBackground(Color.cyan);
                //j.setLayout(null);
                j.setSize(400, 300);
                j.add(jb);
                j.setVisible(true);


            }
        });
        Frame f = new Frame();
        f.add(tf1);
        f.add(tf2);
        f.add(tf3);
        f.add(tf4);
        f.add(tf5);
        f.add(b1);
        //f.add(b2);
        f.add(l1);
        f.add(l2);
        f.add(l3);
        f.add(l4);
        f.add(l5);

        f.setLayout(null);
        f.setSize(400,300);
        f.setBackground(Color.GRAY);
        f.setVisible(true);
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });
    }
}

class login
{
    public login()
    {
        Frame f = new Frame();
        Label l1 = new Label();
        Label l2 = new Label();
        Label l3 = new Label();
        TextField t1 = new TextField();
        t1.setBounds(20,100,100,20);
        l1.setBounds(20,120,60,10);
        l1.setText("Username");
        TextField t2 =  new TextField();
        t2.setBounds(150,100,100,20);
        l2.setBounds(150,120,60,10);
        l2.setText("Password");
        Button b1 = new Button("Login");
        b1.setSize(30,20);
        b1.setBounds(100,200,80,20);
        b1.setBackground(Color.green);
        f.setBackground(Color.cyan);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s1 = t1.getText();
                String s2 = t2.getText();
                if(s1 == null && s2 == null)
                {
                    final JFrame j = new JFrame();
                    JButton jb = new JButton();
                    jb.setText("Please Enter Both Fields");
                    jb.setBackground(Color.white);
                    jb.setForeground(Color.red);
                    j.setBackground(Color.cyan);
                    //j.setLayout(null);
                    j.setSize(300, 200);
                    j.add(jb);
                    j.setVisible(true);
                    j.setLayout(null);
                }
                else
                {
                    a_login a = new a_login();
                    a.a_login1();
                    f.dispose();
                }

            }
        });


        f.add(t1);
        f.add(l1);
        f.add(t2);
        f.add(l2);
        f.add(b1);




        f.setSize(400,300);
        f.setLayout(null);
        f.setVisible(true);

        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });


    }
}

class dashboard
{
    public void d1()
    {
        Frame f1 = new Frame();
        f1.setSize(400,400);
        Label l1 = new Label("Welcome to your Bank");
        l1.setBackground(Color.red);
        l1.setBounds(40,50,200,20);

        f1.add(l1);
        f1.setBackground(Color.cyan);
        f1.setLayout(null);
        f1.setVisible(true);


    }

}


class frame
{
    public frame()
    {
        //Creating a main frame which is our homepage
        Frame f1 = new Frame("Welcome to our ATM");
        Button b1 = new Button("Register");
        Button b2 = new Button("Login");
        b1.setBounds(60,140,60,20);
        b1.setBackground(Color.YELLOW);
        b2.setBounds(250,140,60,20);
        b2.setBackground(Color.pink);
//        b3.setBounds(280,100,70,20);
//        b3.setBackground(Color.gray);
//        b4.setBounds(20,200,90,20);
//        b4.setBackground(Color.green);
//        b5.setBounds(150,200,100,20);
//        b5.setBackground(Color.MAGENTA);
//        b6.setBounds(280,200,70,20);
//        b6.setBackground(Color.pink);
        f1.add(b1);
        f1.add(b2);
//        f1.add(b3);
//        f1.add(b4);
//        f1.add(b5);
//        f1.add(b6);
        Label l1 = new Label("Welcome To Our ATM");
        l1.setBounds(70,40,200,20);
        l1.setAlignment(Label.CENTER);
        l1.setBackground(Color.green);
        f1.add(l1);
// Setting the onclick listener when clicked on the button
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame2 t =  new frame2();
                t.frame2();
            }
        });
        //Setting onclick listener when clicked on button login
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login l = new login();
            }
        });
        //Setting onclick listener to Quickcash button

        //Setting frame size and visibility
        f1.setSize(400,300);
        f1.setLayout(null);
        f1.setBackground(Color.orange);
        f1.setVisible(true);
        //Function to close window on clicking the cut button
        f1.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                f1.dispose();
                System.out.println("Program closed ");
            }
        });
    }

}
//A separate pop up class for always using it
class popup extends Menu implements MenuContainer, Accessible
{

    public void pop_reg()
    {
      final Frame f = new Frame();
      final PopupMenu p = new PopupMenu("Edit");
      MenuItem m = new MenuItem("Thankyou You have registerd ");
      m.setActionCommand("Thankyou You have registerd ");
      p.add(m);


f.add(p);
f.setSize(200,200);
f.setLayout(null);
f.setVisible(true);

    }
    public  void pop_f_login()
    {
         Frame f = new Frame();
         final PopupMenu p = new PopupMenu();
        MenuItem m = new MenuItem("Please Enter Both fields");
        m.setActionCommand("Please Enter Both fields");
        p.add(m);
        f.add(p);

        f.setSize(200,200);
        f.setLayout(null);
        f.setVisible(true);

    }
    public void pop_cw()
    {
        final Frame f = new Frame();
        final PopupMenu p = new PopupMenu("Edit");
        MenuItem m = new MenuItem("Thankyou You have registerd ");
        m.setActionCommand("Thankyou You have registerd ");
        p.add(m);
        f.add(p);
        f.setSize(200,200);
        f.setLayout(null);
        f.setVisible(true);

    }


}
class quick extends Frame
{
    public quick()
    {
        Frame fq = new Frame();
        Label l1 = new Label("Quick cash Withdral of 500 only ");
        Label l2 = new Label("Please collect your Cash");
        l1.setBackground(Color.gray);
        l1.setBounds(40,100,250,20);
        l2.setBackground(Color.orange);
        l2.setBounds(50,200,250,20);
//        l2.setBackground(Color.red);
//        TextField tq = new TextField();
        fq.add(l1);
        fq.add(l2);
        fq.setSize(400,300);
        fq.setBackground(Color.cyan);
        fq.setVisible(true);
        fq.setLayout(null);

        fq.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                fq.dispose();
            }
        });

    }



}

class cw extends Frame
{
    public  cw()
    {
        Frame fcw = new Frame();
        TextField tc = new TextField();
        Button b = new Button("Press OK when done");
        fcw.setBackground(Color.DARK_GRAY);
        tc.setBounds(60,100,150,20);
        Label l= new Label("Enter amount to withdraw");
        l.setBounds(60,150,150,20);
        l.setBackground(Color.ORANGE);
        b.setBounds(60,250,150,20);
        b.setBackground(Color.red);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                final JFrame j = new JFrame();
                JButton jb = new JButton();
                jb.setText("Please Collect Your Cash ");
                jb.setBackground(Color.blue);
                jb.setForeground(Color.red);
                j.setBackground(Color.cyan);
                j.setSize(300, 200);
                j.add(jb);
                j.setVisible(true);

            }
        });

        fcw.add(tc);
        fcw.add(l);
        fcw.add(b);
        fcw.setSize(400,300);
        fcw.setLayout(null);
        fcw.setVisible(true);
fcw.addWindowListener(new WindowAdapter() {
    @Override
    public void windowClosing(WindowEvent e) {
        fcw.dispose();
    }
});
    }
}
class Check_b
{
    public Check_b()
    {
        final JFrame j = new JFrame();
        JButton jb = new JButton();
        jb.setText("You have 1000 in your Account ");
        jb.setBackground(Color.white);
        jb.setForeground(Color.red);
        j.setBackground(Color.red);
        //j.setLayout(null);
        j.setSize(300, 200);
        j.add(jb);
        j.setVisible(true);
    }
}
class Change_p
{
    public Change_p()
    {
        final JFrame j = new JFrame();
        TextField t1 = new TextField();
        TextField t2 = new TextField();
        TextField t3 = new TextField();
        Label l1 = new Label("Enter Old Pin");
        Label l2 = new Label("Enter New Pin");
        Label l3 = new Label("Enter again New Pin");
        Label l4 = new Label();
        t1.setBounds(40,40,200,20);
        l1.setBounds(40,60,80,20);
        t2.setBounds(40,80,200,20);
        l2.setBounds(40,100,100,20);
        t3.setBounds(40,120,200,20);
        l3.setBounds(40,140,150,20);
        l4.setBounds(100,220,60,20);


        Button jb = new Button("Change");
        jb.setBounds(100,220,50,20);
        jb.setBackground(Color.white);
        jb.setForeground(Color.red);

        jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                final JFrame j = new JFrame();
                JButton jb = new JButton();
                jb.setText("Thankyou Your PIN has been changed");
                jb.setBackground(Color.white);
                jb.setForeground(Color.red);
                j.setBackground(Color.red);
                //j.setLayout(null);
                j.setSize(300, 200);
                j.add(jb);
                j.setVisible(true);

            }
        });
        //j.setLayout(null);
        j.setSize(400, 300);
        j.add(jb);
        j.add(t1);
        j.add(t2);
        j.add(t3);
        j.add(l1);
        j.add(l2);
        j.add(l3);
        j.add(jb);
        j.add(l4);
        j.setBackground(Color.red);
        j.setVisible(true);
        j.setLayout(null);


    }

}
class a_login
{
     public void  a_login1()
    {
        //Creating a main frame which is our homepage
        Frame f1 = new Frame("Welcome to our ATM");
        //f1.setBackground(Color.DARK_GRAY);
        Button b3 = new Button("Quick cash");
        Button b4 = new Button("Cash Withdrawl");
        Button b5 = new Button("Check Balance");
        Button b6 = new Button("Change pin");
        b3.setBounds(70,120,100,20);
        b3.setBackground(Color.gray);
        b4.setBounds(180,120,100,20);
        b4.setBackground(Color.CYAN);
        b5.setBounds(70,160,100,20);
        b5.setBackground(Color.MAGENTA);
        b6.setBounds(180,160,100,20);
        b6.setBackground(Color.YELLOW);
        b6.setForeground(Color.red);
        Label l1 = new Label("");
        l1.setBounds(40,50,60,20);
        l1.setBackground(Color.green);
        f1.add(b3);
        f1.add(b4);
        f1.add(b6);

        f1.add(b5);
        f1.add(l1);

        ////////////
        //Setting onclick listener to Quickcash button
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                quick qc = new quick();
            }
        });

        //Setting onclick listener to cash Withdrawl Button
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                cw c = new cw();
            }
        });
        //Setting onclick listener to Check Balance
        b5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Check_b c = new Check_b();
            }
        });
        //Setting onclick listener to Change Pin
        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Change_p cp = new Change_p();
            }
        });

        f1.setSize(400,300);
        f1.setVisible(true);
        f1.setLayout(null);
        //Program for closing window
        f1.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                f1.dispose();
            }
        });

    }
}

public class Virtual_ATM {
    public static void main(String[] args) {


        frame  f1 = new frame();


    }
}
